const { validationResult } = require("express-validator");

const sumar = (num1, num2) => (+num1) + (+num2);
const restar = (num1, num2) => (+num1)-(+num2);
const multiplicar = (num1, num2) => (+num1)*(+num2);
const dividir = (num1, num2) => (+num1)/(+num2);

exports.suma = (req, res, next) => {
    const errors = validationResult(req);

    if (!errors.isEmpty()) {
        const err = new Error('Error');
        err.statusCode = 500;
        err.data = errors.array();
        throw err;
    }

    const sum = sumar(+req.body.numberOne, +req.body.numberTwo);
    const params = {
        body: req.body,
        result: sum
    }

    try {
        res.status(201).json({ message: 'suma', params });
    } catch (err) {
        const error = new Error('Error');
        error.statusCode = 500;
        error.data = err;
        throw error;
    }
}

exports.resta = (req, res) => {
    const errors = validationResult(req);

    if (!errors.isEmpty()) {
        const err = new Error('Error');
        err.statusCode = 500;
        err.data = errors.array();
        throw err;
    }

    const rest = restar(+req.body.numberOne, +req.body.numberTwo);
        const params = {
            body: req.body,
            result: rest
        }

    try {
        res.status(201).json({ message: 'resta', params });
    } catch (err) {

        const error = new Error('Error');
        error.statusCode = 500;
        error.data = err;
        throw error;
    }
}

exports.mult = (req, res) => {
    const errors = validationResult(req);

    if (!errors.isEmpty()) {
        const err = new Error('Error');
        err.statusCode = 500;
        err.data = errors.array();
        throw err;
    }

    const mul = multiplicar(+req.body.numberOne, +req.body.numberTwo);

    const params = {
        body: req.body,
        result: mul
    }

    try {
        res.status(201).json({ message: 'multiplicacion', params });
    } catch (err) {

        const error = new Error('Error');
        error.statusCode = 500;
        error.data = err;
        throw error;
    }
}

exports.div = (req, res) => {
    const errors = validationResult(req);

    if (!errors.isEmpty()) {
        const err = new Error('Error');
        err.statusCode = 500;
        err.data = errors.array();
        throw err;
    }

    const divisor = req.body.numberTwo;
    const div = dividir(+req.body.numberOne, +divisor);


    if (divisor == 0) {
        res.status(400).json({ message: 'No se puede dividir por cero' });
    } else {

        const params = {
            body: req.body,
            result: div
        }

        try {
            res.status(201).json({ message: 'division', params });
        } catch (err) {

            const error = new Error('Error');
            error.statusCode = 500;
            error.data = err;
            throw error;
        }
    }

}